//
//  UserSearchView.swift
//  CineMates
//
//  Created by Aldo Di Giovanni on 28/12/21.
//  Copyright © 2021 Aldo Di Giovanni. All rights reserved.
//

import SwiftUI

struct UserSearchView: View {
    
    @StateObject var userSearchState = UserSearchState()
    
    var body: some View {
        List {
            ForEach(userSearchState.movies) { request in
                NavigationLink(destination: UserCompleteView(request: request)){
                    Text(request.id)
                }
                
            }
        }
        .searchable(text: $userSearchState.query, prompt: "Search users")
        .overlay(overlayView)
        .onAppear { userSearchState.startObserve() }
        .listStyle(.plain)
        .navigationTitle("Search")
    }
    
    @ViewBuilder
    private var overlayView: some View {
        switch userSearchState.phase {
            
        case .empty:
            if userSearchState.trimmedQuery.isEmpty {
                EmptyPlaceholderView(text: "Search for an user", image: Image(systemName: "magnifyingglass"))
            } else {
                ProgressView()
            }
            
        case .success(let values) where values.isEmpty:
            EmptyPlaceholderView(text: "No results", image: Image(systemName: "person"))
            
        case .failure(let error):
            RetryView(text: error.localizedDescription, retryAction: {
                Task {
                    await userSearchState.search(query: userSearchState.query)
                }
            })
            
        default: EmptyView()
        }
    }
}

struct UserSearchView_Previews: PreviewProvider {
    static var previews: some View {
        UserSearchView()
    }
}
