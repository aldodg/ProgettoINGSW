//
//  UserSearchState.swift
//  Cinemates
//
//  Created by Aldo Di Giovanni on 13/01/22.
//  Copyright © 2022 Aldo Di Giovanni. All rights reserved.


import SwiftUI
import Combine
import Foundation

@MainActor
class UserSearchState: ObservableObject {
    
    @Published var query = ""
    @Published private(set) var phase: DataFetchPhase<[User]> = .empty
    
    private var cancellables = Set<AnyCancellable>()
    private let userService: UserService
    
    var trimmedQuery: String {
        query.trimmingCharacters(in: .whitespacesAndNewlines)
    }
    
    var users: [User] {
        phase.value ?? []
    }
    
    init(userService: MovieService = MovieStore.shared) {
        self.userService = userService
    }
    
    func startObserve() {
        guard cancellables.isEmpty else { return }
        
        $query
            .filter { $0.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
            .sink { [weak self] _ in
                self?.phase = .empty
            }
            .store(in: &cancellables)
        
        $query
            .filter { !$0.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
            .debounce(for: 1, scheduler: DispatchQueue.main)
            .sink { query in
                Task { [weak self] in
                    guard let self = self else { return }
                    await self.search(query: query)
                }
            }
            .store(in: &cancellables)
    }
    
    func search(query: String) async {
        if Task.isCancelled { return }
        
        phase = .empty
        
        let trimmedQuery = query.trimmingCharacters(in: .whitespacesAndNewlines)
        
        guard !trimmedQuery.isEmpty else {
            return
        }
        
        do {
            let users = try await userService.searchMovie(query: trimmedQuery)
            if Task.isCancelled { return }
            guard trimmedQuery == self.trimmedQuery else { return }
            phase = .success(users)
        } catch {
            if Task.isCancelled { return }
            guard trimmedQuery == self.trimmedQuery else { return }
            phase = .failure(error)
        }
    }

}

