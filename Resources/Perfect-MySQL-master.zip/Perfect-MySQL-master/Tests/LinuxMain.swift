import XCTest
@testable import PerfectMySQLTests

XCTMain([
	testCase(PerfectMySQLTests.allTests),
	])
