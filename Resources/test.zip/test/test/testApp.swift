//
//  testApp.swift
//  test
//
//  Created by Aldo Di Giovanni on 16/11/21.
//
//
import SwiftUI

@main
struct testApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
