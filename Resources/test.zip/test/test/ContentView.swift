//
//  ContentView.swift
//  test
//
//  Created by Aldo Di Giovanni on 16/11/21.
//

import SwiftUI
import Foundation

struct ContentView: View {
    
    @State var info = [Info]()
    
    var body: some View {
        Text("Hello, world!")
            .padding()
            .onAppear() {
                Api().loadData { (list) in
                    self.info = list.info
                }
            }.navigationTitle("Lists")
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

